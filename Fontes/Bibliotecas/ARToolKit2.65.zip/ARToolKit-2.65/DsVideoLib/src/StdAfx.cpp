 /* ========================================================================
  * PROJECT: DirectShow Video Processing Library
  * ========================================================================
  * Author:  Thomas Pintaric, Vienna University of Technology
  * Contact: mailto:thomas@ims.tuwien.ac.at http://ims.tuwien.ac.at/~thomas
 /* ======================================================================= */


#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
